Charlotte Wright
cwrig21@u.rochester.edu
https://github.com/RandomWright/ReadyNotes

CSC 214
Project 03
The Kitchen Sink Project

The goal of Project 3 is to create an app of your own design that meets requirements.

ReadyNote

This is a self sorting Notes app. There are a lot of notes apps already out there but the goal of
this one is to be the easiest to find what you wrote down before. This will include options to auto
sort notes by topic, content and time. So if it a list with food items it would sorted as a groceries
list and if their is a phone number is will be sorted as a contact info. This is a place to quickly
write down notes and make it a useful reason to gather knowledge.
The main compounds will be a the note space which will have options about how you want to
view and write, a sorting function and a customization options for the user.
The stretch goal will to have notes show up based on your schedule and learn when you have
activities based on when you put notes in. Also have reminders based on what your notes say.


The main Fragment is where you can create notes and view a list of all the notes. You can also add a photo as a note or send a note as a email or reminder. The notes are saved in a SQL database and auto sorted by time and key words. 

There are dialogs to see the image and the full note.

The List Fragment is the notes sorted into the weekday and CSC 214 catorgies. 

The Advance Fragment are used to record videos.

It is a pretty GREEN color;

Basic Features:
They are there.

Advanced Features:

Photo
You can add a picture to a note by clicking the Add Photo Button
Then you can view

Video
In the Advance Fragment, you can record a video because I needed another advanced feature.

Reminder Service:
Will send a note as a reminder in a min
-User Remind Me Button

Playing sounds with SoundPool
-Sounds play when app is turned
-and some random other places

Send Email of the Note with Send Email Button
-only works if you have email set up on your photo

Notes with phone numbers, emails, or website will link out to other apps
-so photo numers will open photo app



I affirm that i did not give or receive any unauthorized help on this project, and that all work will is my own

----("all work will is my own???) all work will be my own


Future plans:
Add more catorgizes and custom options
-had to focus more on the requirments then important app things
I will still be adding things on github after the project is over